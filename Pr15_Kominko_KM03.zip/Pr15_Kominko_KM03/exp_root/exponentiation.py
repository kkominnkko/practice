def exp2(a):
    a = a*a
    return round(a, 3)


def exp3(b):
    b = b**3
    return round(b, 3)
