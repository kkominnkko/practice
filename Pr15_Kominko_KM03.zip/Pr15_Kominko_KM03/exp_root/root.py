def root3(a):
    if a < 0:
        a = -((-a)**(1/3))
    else:
        a = a**(1/3)
    return round(a, 3)


def root2(a):
    a = a ** (1 / 2)
    return round(a, 3)

