import math
def log(a,b):
    l = math.log(a, b)
    return round(l, 3)

def ln(b):
    l = math.log1p(b)
    return round(l, 3)

def lg(b):
    l = math.log10(b)
    return round(l, 3)