from factorial import factorial as fact
from exp_root import exponentiation as exp
from exp_root import root
from logarithm import logarithm as log


def checker():
    while True:
        try:
            a = float(input("Введіть число:"))
            if a <= 0:
                print("Введіть додатнє число")
                return checker()
            else:
                return a
        except ValueError:
            print("Введіть коректні дані")


def log_checker():
    while True:
        try:
            a = float(input("Введіть основу:"))
            if a <= 0:
                print("Введіть натуральне число")
                return log_checker()
            elif a == 1:
                print("Основа не може дорівнювати одиниці")
                return log_checker()
            else:
                return a
        except ValueError:
            print("Введіть коректні дані")


def inp():
    a = float(input("Введіть число:"))
    return a


print("Для обрахунків натисність відповідні клавіші \nФакторіал - 1 \nКвадрат числа - 2 \nКуб числа - 3 "
      "\nКвадратний корінь числа - 4 \nКубічний корінь числа - 5 \nЛогарифм - 6 \nНатуральний логарифм - 7 "
      "\nДесятковий логарифм - 8")
print("Значення округлюються до 3 знаків після коми")


def main():
    while True:
        choice = int(input("Виберіть одну з запропонованих функцій:"))
        if choice == 1:
            res = fact.fact(checker())
            print(res)
        elif choice == 2:
            res = exp.exp2(inp())
            print(res)
        elif choice == 3:
            res = exp.exp3(inp())
            print(res)
        elif choice == 4:
            res = root.root2(checker())
            print(res)
        elif choice == 5:
            res = root.root3(inp())
            print(res)
        elif choice == 6:
            res = log.log(log_checker(), checker())
            print(res)
        elif choice == 7:
            res = log.ln(checker())
            print(res)
        elif choice == 8:
            res = log.lg(checker())
            print(res)
        end = int(input("Для завершення роботи натисніть 0, для продовження будь-яку цифру:"))
        if end == 0:
            break
        else:
            main()


if __name__ == '__main__':
    main()
