def fact(n):
    a = 1
    while n > 1:
        a = a * n
        n = n - 1
    return a